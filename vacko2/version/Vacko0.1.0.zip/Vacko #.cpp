#include <fstream> 
#include <iostream>
#include <unistd.h>
#include <bits/stdc++.h>
#include<windows.h>
#include<time.h>
#include<ctime>
using namespace std;
void fun(const string a)
{
	int ussleepAS=10000;
	size_t len = a.size();
	for(int i = 0;i<a.size();i++)
	{
		cout << a[i];
		fflush(stdin);
		usleep(ussleepAS);
	}
	cout << endl;
}
int main()
{
	string Juese,NAME;
	int YEAR,MON,DAY,BANday,TWOYEAR;
	time_t timer;
	time(&timer);
	tm* t_tm = localtime(&timer);
	YEAR=t_tm->tm_year+1900;
	MON=t_tm->tm_mon+1;
	DAY=t_tm->tm_mday+7;
	BANday=t_tm->tm_mday;
	TWOYEAR=t_tm->tm_year+1910;

	fun("****************************Vacko*******************************");
	fun("************************Maker:lemon-p***************************");
    Sleep(2000);
	string pathab = "./log/login log.txt";
	ifstream in_fileAB(pathab, ios::in);
	string logininf;
	while(getline(in_fileAB, logininf))
	{
		//读取登录的数据
	}
	string pathG = "./log/login yes log.txt";
	ifstream in_fileFa(pathG, ios::in);
	string loginyesinf;
	while(getline(in_fileFa, loginyesinf)) 
	{
		//读取登录成功的数据
	}
	string pathFA = "./log/enroll log.txt";
	ifstream in_fileFA(pathFA, ios::in);
	string enrollinf;
	while(getline(in_fileFA, enrollinf))
	{
		//读取注册信息
	}
	
	string pathBAN = "./Inf/user/ban.txt";
	ifstream in_fileBAN(pathBAN, ios::in);
	string BAN;
	getline(in_fileBAN, BAN); //读取uid数据
	
	
    if(logininf=="no")
	{
		string UserN,PassW;
		cout<<"您还没有注册我们账号"<<endl;
		cout<<"请输入您想注册的账户名:"<<endl;
		cin>>UserN;
		cout<<"请输入密码："<<endl;
		cin>>PassW;
		string pathA = "./log/enroll log.txt";  
		ofstream out_file(pathA, ios::out | ios::app); 
		out_file <<UserN;	
		
		string pathC = "./backup/log/enroll log backup.txt";  
		ofstream out_fileA(pathC, ios::out | ios::app); 
		out_fileA <<UserN;	 //写入注册的账户信息
		
		string pathJ = "./log/PassW log.txt";  
		ofstream out_fileN(pathJ, ios::out | ios::app); 
		out_fileN <<PassW;	 //写入注册的账户信息
		
		string pathD = "./log/login yes log.txt";  
		ofstream out_fileB(pathD, ios::out | ios::app); 
		out_fileB<<"1";	
		
		string pathE = "./backup/log/login yes log backup.txt"; 
		ofstream out_fileC(pathE, ios::out | ios::app); 
		out_fileC<<"1";//写入登录信息
		
		string pathH = "./log/login log.txt";  
		ofstream out_fileH(pathH, ios::out | ios::app); 
		out_fileH<<"1";	
		
		string pathK= "./backup/log/login log backup.txt"; 
		ofstream out_fileK(pathK, ios::out | ios::app); 
		out_fileK<<"1";//写入登录信息
		

		
		int UID=10000;
        cout<<"您的账户注册成功，请确认信息：用户名："<<UserN<<"密码："<<PassW<<endl;
		UID+=1;
		
		string pathUID= "./log/uid log.txt"; 
		ofstream out_fileUID(pathUID, ios::out | ios::app); 
		out_fileUID<<UID;//写入uid信息
		
		Sleep(2000);
		cout<<"请牢记信息，否则可能会造成账号信息丢失的情况。"<<endl;
		cout<<"再次打开即可进入界面。"<<endl;
	}

	if(loginyesinf=="1" && BAN=="0" || BAN=="010" || BAN=="01010")
	{
		string InputPassW,Inputchoose;
		int WrN=0;
		cout<<enrollinf<<endl;
		cout<<"上面账户是您的账号吗？：yes/no"<<endl;
		cin>>Inputchoose;
		if(Inputchoose=="yes")
		{
			Sleep(2000);
			while(1)
			{
				string pathRM="./log/Rm log.txt";
				ifstream in_fileRM(pathRM,ios::in);
				string RmPASS;
				while(getline(in_fileRM,RmPASS))
				{
					//读取记住密码信息
				}
				if(RmPASS=="n")
				{
					string pathPASSW="./log/PassW log.txt";
					ifstream in_fileBHBH(pathPASSW,ios::in);
					string PassWord;
					getline(in_fileBHBH,PassWord);//读取密码
					cout<<"请输入密码："<<endl;
					cin>>InputPassW;
					if(InputPassW==PassWord)
					{
						cout<<"密码正确。"<<endl;
						string RmPassw;
						cout<<"您想要记住这个密码吗？：yes/no"<<endl;
						cout<<"记住密码后，下次登录即可不再输入密码。"<<endl;
						cin>>RmPassw;
						string pathKS= "./log/Rm log.txt"; 
						ofstream out_fileKS(pathKS, ios::out | ios::app); 
						out_fileKS<<"rm";//写入密码信息
						break;
					}
					else 
					{
						cout<<"密码不正确，请检查账户信息是否正确或密码是否正确。"<<endl;
						WrN+=1;
						if(WrN==3)
						{
							cout<<"您已经连续三次输入错误，即将退出。。。。"<<endl;
							return 0;
						}
					}
				}
				if(RmPASS=="nrm")
				{
					cout<<"您已经记住密码。可以直接登录"<<endl;
					Sleep(2000);
					break;
				}
			}
		}
        if(Inputchoose=="no")
		{
			cout<<"您可以选择联系客服来索取空白配置文件，到时候您可以再次注册新的账户，若您要登录其他账户，请进入游戏内更改。"<<endl;
			cout<<"客服联系方式：邮箱 cpddabc@126.com QQ：2833379812"<<endl;
			Sleep(2000);
			return 0;
		}
        cout<<"欢迎登录，尊敬的"<<enrollinf<<endl;
		cout<<"正在读取玩家信息。。。"<<endl;
		string path = "./Inf/user inf.txt";
		ifstream in_file(path, ios::in);
		string gamerinf;
		while(getline(in_file, gamerinf)) 
		{
			//读取玩家的数据
		}
		Sleep(3000);
		string pathY = "./backup/Inf/backup inf.txt";
		ifstream in_fileASAS(pathY, ios::in);
		string BACKUPgamerinf;
		while(getline(in_fileASAS, BACKUPgamerinf)) 
		{
			//读取备份数据
		}
		cout<<"正在分析数据差异。。。"<<endl;
		Sleep(2000);
		if(gamerinf==BACKUPgamerinf)
		{
			string pathQWE = "./Inf/user inf.txt";
			ifstream in_fileQWE(pathQWE, ios::in);
			string gamerinfa;
			getline(in_fileQWE, gamerinfa);
			
			string STARTjq;
			string pathUIDB = "./log/uid log.txt";
			ifstream in_fileUIDB(pathUIDB, ios::in);
			string UIDloLL;
			getline(in_fileUIDB, UIDloLL); //读取uid数据
			
			cout<<"数据分析完成。。。"<<endl;
			cout<<"正在为您加载信息。..."<<endl;
		    Sleep(2000);
			fun("loading.........................................................................Finish！！.");
			system("cls");
			STARTjq=gamerinfa.substr(2,3);
			if(gamerinfa=="00")
			{
				int ChooseCh;
				Sleep(2000);
				fun("loading.........................................................................Finish！！.");
				cout<<"2300年前，人与魔展开了一场战争，就在人陷入下风之时....."<<endl;
				Sleep(4000);
				cout<<"只见一人操纵海浪，那海水肆意的冲刷着，狂风呼啸着..."<<endl;
				Sleep(4000);
				cout<<"最终人类赢得了这场战争，而操纵海浪之人却蔽在深山绝云之间，人们将她视为神明..."<<endl;
				Sleep(4000);
				cout<<"就在人们以为有了神明的庇护，可以安居乐业时，魔却再次袭来，领头人正是！..."<<endl;
				Sleep(5000);
				system("cls");
				cout<<"那位：‘神明’。"<<endl;
				Sleep(3000);
				system("cls");
				cout<<"在反击中，二人"<<endl;
				Sleep(3500);
				cout<<"“铭”和”姳“，被卷进了战争之中，突然一道闪波袭来，而反应的时间很短。"<<endl;
				Sleep(2000);
				while(1)
				{
					cout<<"情急之下：（1.”铭“救了”姳“）（2.”姳“救了”铭）"<<endl;
					cin>>ChooseCh;
					if(ChooseCh==1)
					{
						cout<<"最终哥哥救了妹妹”姳“，而他被闪波击中。。"<<endl;
						cout<<"掉下了深渊，生死未卜。”姳“也因为强大的冲击，昏了过去。"<<endl;
						string pathGAMECH= "./Inf/user inf.txt"; 
						ofstream out_fileGAMECH(pathGAMECH, ios::out | ios::app); 
						out_fileGAMECH<<"0";//写入角色信息
						
						string pathGAMECHback= "./backup/inf/backup inf.txt"; 
						ofstream out_fileGAMECHback(pathGAMECHback, ios::out | ios::app); 
						out_fileGAMECHback<<"0";//写入角色信息
						
						Sleep(3000);
						cout<<"请输入游戏名称："<<endl;
						cin>>NAME;
						
						string pathGAMENAME= "./Inf/user/name.txt"; 
						ofstream out_fileGAMENAME(pathGAMENAME, ios::out | ios::app); 
						out_fileGAMENAME<<NAME;//写入名称信息
						
						cout<<"再次打开即可进入。。。"<<endl;
						break;
					}
					if(ChooseCh==2)
					{
						cout<<"最终妹妹救了哥哥”铭“，而她被闪波击中。。"<<endl;
						cout<<"掉下了深渊，生死未卜。”铭“也因为强大的冲击，昏了过去。"<<endl;
						
						string pathGAMECH= "./Inf/user inf.txt"; 
						ofstream out_fileGAMECH(pathGAMECH, ios::out | ios::app); 
						out_fileGAMECH<<"1";//写入角色信息
						
						string pathGAMECHback= "./backup/inf/backup inf.txt"; 
						ofstream out_fileGAMECHback(pathGAMECHback, ios::out | ios::app); 
						out_fileGAMECHback<<"1";//写入角色信息
						Sleep(3000);
						cout<<"请输入游戏名称："<<endl;
						cin>>NAME;
						
						string pathGAMENAME= "./Inf/user/name.txt"; 
						ofstream out_fileGAMENAME(pathGAMENAME, ios::out | ios::app); 
						out_fileGAMENAME<<NAME;//写入名称信息
						
						cout<<"再次打开即可进入。。。"<<endl;
						break;
					}
					else cout<<"在两人中选择一人。"<<endl;
				}
			}
			if(STARTjq=="0")
			{

				Juese="姳";
			}
			if(STARTjq=="1")
			{
				Juese=="铭";
			} 
			if(gamerinf!="00")
			{	
				string pathlevel = "./Inf/user/level.txt";
				ifstream in_filelevel(pathlevel, ios::in);
				string levelLO;
				getline(in_filelevel,levelLO);//读取等级信息
				
				string pathmoni = "./Inf/user/moni.txt";
				ifstream in_filemoni(pathmoni, ios::in);
				string moni;
				getline(in_filemoni,moni);//读取摩尼信息
				
				string pathEXP = "./Inf/user/exp.txt";
				ifstream in_fileEXP(pathEXP, ios::in);
				string exp;
				getline(in_fileEXP,exp);//读取经验信息
				
				int chooseG; 
			    string pathNAME = "./Inf/user/name.txt";
				ifstream in_fileNAME(pathNAME, ios::in);
				string gameNAME;
				getline(in_fileNAME,gameNAME);//读取名称信息
				
				
				string pathTast = "./Inf/user/tast.txt";
				ifstream in_filetast(pathTast, ios::in);
				string Tast;
				getline(in_filetast,Tast);//读任务信息
				
                string pathHD = "./Inf/user/hd.txt";
				ifstream in_fileHD(pathHD, ios::in);
				string HD;
				getline(in_fileHD,HD);//读活动信息
				
				while(1)
				{
				

					string pathlevel = "./Inf/user/level.txt";
					ifstream in_filelevel(pathlevel, ios::in);
					string levelLO;
					getline(in_filelevel,levelLO);//读取等级信息
					
					string pathmoni = "./Inf/user/moni.txt";
					ifstream in_filemoni(pathmoni, ios::in);
					string moni;
					getline(in_filemoni,moni);//读取摩尼信息
					
					string pathEXP = "./Inf/user/exp.txt";
					ifstream in_fileEXP(pathEXP, ios::in);
					string exp;
					getline(in_fileEXP,exp);//读取经验信息
					
					int chooseG; 
					string pathNAME = "./Inf/user/name.txt";
					ifstream in_fileNAME(pathNAME, ios::in);
					string gameNAME;
					getline(in_fileNAME,gameNAME);//读取名称信息
					
					
					string pathTast = "./Inf/user/tast.txt";
					ifstream in_filetast(pathTast, ios::in);
					string Tast;
					getline(in_filetast,Tast);//读任务信息
					
					string pathHD = "./Inf/user/hd.txt";
					ifstream in_fileHD(pathHD, ios::in);
					string HD;
					getline(in_fileHD,HD);//读活动信息
					
					int att=0,boomatt=50,boomhan=5,blood=1000,def=100,wpatt,zbatt,wpbt,wpbh,zbbt,zbbh,wpblo,wpdef,zbblo,zbdef;
					float ratt,rbt,rblood,rdef;
					int chongneng=0;
                    int nowexp,nowmoni;
					
					
					string task11,task12,Want;
					int task11endtask12;//13
					cout<<"----------------------------------Vacko Uid:"<<UIDloLL<<"--------------------------------"<<endl;
					cout<<"1.任务 2.背包 3.角色 4.综合 5.账户 6.活动 7.公告(新人必看!)"<<endl;
					cin>>chooseG;
					if(chooseG==1)
					{	
						task11=Tast.substr(0,1);
						task12=Tast.substr(1,1);
						float task11monstersBlood=50;
						//读取任务信息
						if(task11=="0")
						{

							string attchoose;
							double long task11attm,task11bfatt1,task11bfatt2,task11bfatt3,task11bfatt4,task11bfatt5,killmonsters1;
							cout<<"1.主线1-1:苏醒后，你处在陌生的环境，前方貌似有一座繁华的城市，但面前有魔物挡住了去路：（击败魔物2个，获得200EXP，10000摩尼)"<<endl;
							cout<<"你要接的任务："<<endl;
							cin>>Want;
							if(Want=="1")
							{
								while(1)
								{
									cout<<"前面有魔物,使用普攻击败它 （1.普攻）："<<endl;
									cin>>attchoose;
									if(attchoose=="1")
									{
										srand(unsigned(time(0)));
										int a= rand()%10+1;	
										if(a==2 || a==1 ||a==3 || a==4 ||a==5 || a==6 || a==7 ||a==8 || a==9 || a==10 || a==0)
										{
											task11attm=ratt+ratt*rbt/100;
											cout<<"暴击！:"<<task11attm<<endl;
											chongneng+=20;
											task11monstersBlood=task11monstersBlood-task11attm;
											Sleep(1500);
										}
										else
										{
											task11attm=ratt+5;
											cout<<"普通伤害:"<<task11attm<<endl;
											task11monstersBlood=task11monstersBlood-task11attm;
											chongneng+=10;
											Sleep(1500);
										}
										
										if(task11monstersBlood<=0)
										{
											chongneng+=50;
											cout<<"击杀一魔物!"<<endl;
											cout<<"充能值："<<chongneng<<endl;
											killmonsters1=1;
											Sleep(1500);
										}
										if(chongneng>=50 && killmonsters1==1)
										{
											break;
										}
									}
								}
								
                                cout<<"前方来了一只魔物首领！"<<endl;
								cout<<"输入Q并且充能值>=50时即可使用爆发技能（光连影刃）:"<<endl;
								task11monstersBlood=100;
								ratt+=5;
								task11bfatt1=ratt;
								task11bfatt2=ratt+10;
								task11bfatt3=ratt+50;
								task11bfatt4=ratt+ratt*rbt/100;
								task11bfatt5=ratt+ratt*rbt/20;
								ratt=ratt-5;
								cin>>attchoose;
								if(attchoose=="q" || attchoose=="Q")
								{
									chongneng=chongneng-50;
									cout<<Juese<<":光影."<<endl;
									Sleep(1500);
									cout<<"连刃！"<<endl;
									cout<<"斩！1："<<task11bfatt1<<endl;
									Sleep(1000);
									cout<<"碎！2："<<task11bfatt2<<endl;
									Sleep(200);
									cout<<"影！3："<<task11bfatt3<<endl;
									Sleep(200);
									cout<<"爆！4："<<task11bfatt4<<endl;
									Sleep(1000);
									cout<<"裁~~~~~~！"<<endl;
									Sleep(2000);
									cout<<"决！5："<<task11bfatt5<<endl;
									task11monstersBlood=task11monstersBlood-(task11bfatt1+task11bfatt2+task11bfatt3+task11bfatt4,task11bfatt5);
									if(task11monstersBlood<=0)
									{
										cout<<"击杀一魔物首领."<<endl;
										chongneng+=20;
										cout<<"完成任务！"<<endl;
										std::ofstream ofile("./Inf/user/tast.txt");
										ofile << "10000";
										task11endtask12=1;
										if(exp=="0")
										{
											std::ofstream ofile("./Inf/user/exp.txt");
											ofile << "200";
										}
										if(moni=="0")
										{
											std::ofstream ofile("./Inf/user/moni.txt");
											ofile << "10000";
										}
										if(exp!="0")
										{
	                                        
										}
									}
									else 
									{
										cout<<"一招未能击杀，魔物开始反击！"<<endl;
										Sleep(2000);
										if(rdef>=100)
										{
											cout<<"闪避成功！"<<endl;
										}
										if(rdef==90 || rdef==80 ||rdef==70 || rdef==60)
										{
											srand(unsigned(time(0)));
											int b= rand()%10+1;	
											if(b==1 || b==2 || b==3 || b==4 ||b==5)
											{
												cout<<"闪避成功！"<<endl;
											}
											else
											{
												cout<<"任务失败！"<<endl;
											}
										}
										if(rdef==50 || rdef==40 || rdef==30)
										{
											srand(unsigned(time(0)));
											int b= rand()%10+1;	
											if(b==1 || b==2 || b==3 || b==4)
											{
												cout<<"闪避成功！"<<endl;
											}
											else
											{
												cout<<"任务失败！"<<endl;
											}
										}
										if(rdef==20 || rdef==10 || rdef==5)
										{
											srand(unsigned(time(0)));
											int b= rand()%10+1;	
											if(b==1)
											{
												cout<<"闪避成功！"<<endl;
											}
											else
											{
												cout<<"任务失败！"<<endl;
											}
										}
									}
								}
								//任务主线1-1
							}
						}
						if(task12=="0" && task11=="1")
						{
							cout<<"主线1-2:————————"<<endl;
						}
					}
					if(chooseG==2)
					{
						cout<<"背包中的物品："<<endl;
						string pathBAG = "./Inf/user/bag/bagwp.txt";
						ifstream in_fileBAG(pathBAG, ios::in);
						string BAG;
						getline(in_fileBAG, BAG); //读取背包数据
						
						int lenth=0;
						string fenxi;
						
						lenth=BAG.length();
						
						if(lenth/2==0)
						{
							cout<<"背包是空的."<<endl;
						}
						if(lenth/2==1)
						{
						    fenxi=BAG.substr(0,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
						}
						if(lenth/2==2)
						{
							fenxi=BAG.substr(0,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(2,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
						}
						if(lenth/2==3)
						{
							fenxi=BAG.substr(0,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(2,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(4,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
						}
						if(lenth/2==4)
						{
							fenxi=BAG.substr(0,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(2,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(4,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(6,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
						}
						if(lenth/2==5)
						{
							fenxi=BAG.substr(0,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(2,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(4,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(6,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(8,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
						}
						if(lenth/2==6)
						{
							fenxi=BAG.substr(0,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(2,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(4,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(6,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(8,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(10,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
						}
						if(lenth/2==7)
						{
							fenxi=BAG.substr(0,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(2,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(4,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(6,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(8,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(10,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(12,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
						}
						if(lenth/2==8)
						{
							fenxi=BAG.substr(0,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(2,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(4,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(6,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(8,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(10,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(12,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(14,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
						}
						if(lenth/2==9)
						{
							fenxi=BAG.substr(0,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(2,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(4,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(6,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(8,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(10,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(12,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(14,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(16,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
						}
						if(lenth/2==10)
						{
							fenxi=BAG.substr(0,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(2,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(4,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(6,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(8,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(10,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(12,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(14,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(16,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(18,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
						}
						if(lenth/2==11)
						{
							fenxi=BAG.substr(0,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(2,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(4,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(6,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(8,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(10,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(12,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(14,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(16,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(18,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
							fenxi=BAG.substr(20,2);
							if(fenxi=="01")
							{
								cout<<"新手铁剑"<<" "<<endl;
							}
							if(fenxi=="02")
							{
								cout<<"新手铁甲"<<" "<<endl;
							}
							if(fenxi=="03")
							{
								cout<<"雾切之回光"<<" "<<endl;
							}
							if(fenxi=="04")
							{
								cout<<"精良铁甲"<<" "<<endl;
							}
							if(fenxi=="05")
							{
								cout<<"烈火剑"<<" "<<endl;
							}
							if(fenxi=="06")
							{
								cout<<"烈火套装"<<" "<<endl;
							}
							if(fenxi=="07")
							{
								cout<<"终末磋叹之诗"<<" "<<endl;
							}
							if(fenxi=="08")
							{
								cout<<"传说套装"<<" "<<endl;
							}
							if(fenxi=="09")
							{
								cout<<"天空之脊"<<" "<<endl;
							}
							if(fenxi=="10")
							{
								cout<<"神·最终支配之剑"<<" "<<endl;
							}
							if(fenxi=="11")
							{
								cout<<"神·最终守护之甲"<<" "<<endl;
							}
						}
						//背包系统
					}
					if(chooseG==3)
					{ 
						int choosezhuangbei;
						string pathNOW = "./Inf/user/bag/now.txt";
						ifstream in_fileNOW(pathNOW, ios::in);
						string NOW;
						getline(in_fileNOW,NOW);//读武器信息
						
						string pathNOWzb = "./Inf/user/bag/nowzb.txt";
						ifstream in_fileNOWzb(pathNOWzb, ios::in);
						string NOWzb;
						getline(in_fileNOWzb,NOWzb);//读装备信息
						
						string nowwp,nowzb,rnowwp,rnowzb,fenxi2,fenxi3,fenxi4,fenxi5,fenxi6,fenxi7,fenxi8,fenxi9,fenxi10,fenxi11;
						nowwp=NOW.substr(0,2);
						nowzb=NOWzb.substr(0,2);
						if(nowwp=="00")
						{
							rnowwp="未装备";
						}
						if(nowwp=="01")
						{
							rnowwp="新手铁剑";
						}
						if(nowwp=="03")
						{
							rnowwp="雾切之回光";
						}
						if(nowwp=="05")
						{
							rnowwp="烈火剑";
						}
						if(nowwp=="07")
						{
							rnowwp="终末磋叹之诗";
						}
						if(nowwp=="09")
						{
							rnowwp="天空之脊";
						}
						if(nowwp=="10")
						{
							rnowwp="神·最终支配之剑";
						}
						if(nowzb=="00")
						{
							rnowzb="未装备";
						}
						if(nowzb=="02")
						{
							rnowzb="新手铁甲";
						}
						if(nowzb=="04")
						{
							rnowzb="精良铁甲";
						}
						if(nowzb=="06")
						{
							rnowzb="烈火套装";
						}
						if(nowzb=="08")
						{
							rnowzb="传说套装";
						}
						if(nowzb=="11")
						{
							rnowzb="神·最终守护之甲";
						}
						cout<<"当前角色："<<Juese<<endl;
						cout<<"当前武器："<<rnowwp<<endl;
						cout<<"当前装备："<<rnowzb<<endl;
						cout<<"1.装备 2.数值面板 3.返回———————》"<<endl;
						cin>>choosezhuangbei;
						if(choosezhuangbei==1)
						{							
							string pathBAG = "./Inf/user/bag/bagwp.txt";
							ifstream in_fileBAG(pathBAG, ios::in);
							string BAG;
							getline(in_fileBAG, BAG); //读取背包数据
							
							int lenth=0;
							string fenxi;
							
							lenth=BAG.length();
							
							if(lenth/2==0)
							{
								cout<<"背包是空的."<<endl;
							}
							if(lenth/2==1)
							{
								fenxi=BAG.substr(0,2);
								if(fenxi=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
									
								}
								if(fenxi=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
							}
							if(lenth/2==2)
							{
								fenxi=BAG.substr(0,2);
								if(fenxi=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi2=BAG.substr(2,2);
								if(fenxi2=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi2=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi2=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi2=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi2=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi2=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi2=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi2=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi2=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi2=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi2=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
							}
							if(lenth/2==3)
							{
								fenxi=BAG.substr(0,2);
								if(fenxi=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi2=BAG.substr(2,2);
								if(fenxi2=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi2=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi2=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi2=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi2=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi2=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi2=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi2=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi2=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi2=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi2=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi3=BAG.substr(4,2);
								if(fenxi3=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi3=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi3=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi3=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi3=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi3=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi3=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi3=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi3=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi3=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi3=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
							}
							if(lenth/2==4)
							{
								fenxi=BAG.substr(0,2);
								if(fenxi=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi2=BAG.substr(2,2);
								if(fenxi2=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi2=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi2=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi2=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi2=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi2=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi2=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi2=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi2=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi2=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi2=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi3=BAG.substr(4,2);
								if(fenxi3=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi3=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi3=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi3=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi3=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi3=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi3=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi3=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi3=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi3=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi3=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi4=BAG.substr(6,2);
								if(fenxi4=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi4=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi4=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi4=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi4=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi4=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi4=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi4=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi4=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi4=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi4=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
							}
							if(lenth/2==5)
							{
								fenxi=BAG.substr(0,2);
								if(fenxi=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi2=BAG.substr(2,2);
								if(fenxi2=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi2=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi2=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi2=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi2=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi2=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi2=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi2=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi2=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi2=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi2=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi3=BAG.substr(4,2);
								if(fenxi3=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi3=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi3=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi3=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi3=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi3=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi3=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi3=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi3=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi3=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi3=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi4=BAG.substr(6,2);
								if(fenxi4=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi4=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi4=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi4=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi4=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi4=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi4=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi4=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi4=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi4=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi4=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi5=BAG.substr(8,2);
								if(fenxi5=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi5=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi5=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi5=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi5=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi5=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi5=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi5=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi5=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi5=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi5=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
							}
							if(lenth/2==6)
							{
								fenxi=BAG.substr(0,2);
								if(fenxi=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi2=BAG.substr(2,2);
								if(fenxi2=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi2=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi2=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi2=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi2=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi2=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi2=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi2=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi2=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi2=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi2=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi3=BAG.substr(4,2);
								if(fenxi3=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi3=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi3=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi3=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi3=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi3=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi3=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi3=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi3=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi3=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi3=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi4=BAG.substr(6,2);
								if(fenxi4=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi4=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi4=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi4=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi4=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi4=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi4=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi4=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi4=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi4=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi4=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi5=BAG.substr(8,2);
								if(fenxi5=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi5=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi5=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi5=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi5=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi5=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi5=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi5=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi5=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi5=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi5=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi6=BAG.substr(10,2);
								if(fenxi6=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi6=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi6=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi6=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi6=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi6=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi6=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi6=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi6=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi6=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi6=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
							}
							if(lenth/2==7)
							{
								fenxi=BAG.substr(0,2);
								if(fenxi=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi2=BAG.substr(2,2);
								if(fenxi2=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi2=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi2=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi2=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi2=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi2=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi2=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi2=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi2=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi2=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi2=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi3=BAG.substr(4,2);
								if(fenxi3=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi3=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi3=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi3=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi3=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi3=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi3=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi3=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi3=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi3=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi3=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi4=BAG.substr(6,2);
								if(fenxi4=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi4=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi4=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi4=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi4=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi4=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi4=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi4=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi4=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi4=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi4=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi5=BAG.substr(8,2);
								if(fenxi5=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi5=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi5=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi5=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi5=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi5=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi5=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi5=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi5=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi5=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi5=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi6=BAG.substr(10,2);
								if(fenxi6=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi6=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi6=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi6=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi6=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi6=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi6=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi6=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi6=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi6=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi6=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi7=BAG.substr(12,2);
								if(fenxi7=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi7=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi7=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi7=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi7=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi7=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi7=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi7=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi7=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi7=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi7=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
							}
							if(lenth/2==8)
							{
								fenxi=BAG.substr(0,2);
								if(fenxi=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi2=BAG.substr(2,2);
								if(fenxi2=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi2=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi2=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi2=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi2=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi2=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi2=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi2=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi2=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi2=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi2=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi3=BAG.substr(4,2);
								if(fenxi3=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi3=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi3=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi3=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi3=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi3=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi3=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi3=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi3=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi3=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi3=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi4=BAG.substr(6,2);
								if(fenxi4=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi4=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi4=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi4=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi4=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi4=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi4=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi4=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi4=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi4=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi4=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi5=BAG.substr(8,2);
								if(fenxi5=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi5=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi5=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi5=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi5=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi5=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi5=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi5=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi5=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi5=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi5=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi6=BAG.substr(10,2);
								if(fenxi6=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi6=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi6=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi6=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi6=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi6=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi6=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi6=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi6=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi6=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi6=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi7=BAG.substr(12,2);
								if(fenxi7=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi7=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi7=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi7=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi7=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi7=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi7=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi7=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi7=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi7=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi7=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi8=BAG.substr(14,2);
								if(fenxi8=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi8=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi8=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi8=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi8=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi8=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi8=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi8=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi8=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi8=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi8=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
							}
							if(lenth/2==9)
							{
								fenxi=BAG.substr(0,2);
								if(fenxi=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi2=BAG.substr(2,2);
								if(fenxi2=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi2=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi2=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi2=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi2=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi2=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi2=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi2=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi2=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi2=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi2=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi3=BAG.substr(4,2);
								if(fenxi3=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi3=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi3=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi3=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi3=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi3=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi3=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi3=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi3=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi3=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi3=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi4=BAG.substr(6,2);
								if(fenxi4=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi4=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi4=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi4=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi4=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi4=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi4=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi4=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi4=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi4=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi4=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi5=BAG.substr(8,2);
								if(fenxi5=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi5=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi5=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi5=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi5=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi5=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi5=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi5=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi5=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi5=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi5=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi6=BAG.substr(10,2);
								if(fenxi6=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi6=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi6=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi6=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi6=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi6=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi6=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi6=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi6=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi6=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi6=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi7=BAG.substr(12,2);
								if(fenxi7=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi7=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi7=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi7=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi7=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi7=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi7=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi7=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi7=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi7=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi7=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi8=BAG.substr(14,2);
								if(fenxi8=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi8=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi8=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi8=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi8=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi8=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi8=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi8=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi8=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi8=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi8=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi9=BAG.substr(16,2);
								if(fenxi9=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi9=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi9=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi9=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi9=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi9=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi9=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi9=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi9=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi9=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi9=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
							}
							if(lenth/2==10)
							{
								fenxi=BAG.substr(0,2);
								if(fenxi=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi2=BAG.substr(2,2);
								if(fenxi2=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi2=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi2=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi2=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi2=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi2=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi2=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi2=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi2=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi2=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi2=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi3=BAG.substr(4,2);
								if(fenxi3=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi3=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi3=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi3=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi3=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi3=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi3=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi3=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi3=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi3=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi3=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi4=BAG.substr(6,2);
								if(fenxi4=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi4=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi4=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi4=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi4=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi4=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi4=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi4=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi4=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi4=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi4=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi5=BAG.substr(8,2);
								if(fenxi5=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi5=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi5=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi5=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi5=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi5=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi5=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi5=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi5=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi5=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi5=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi6=BAG.substr(10,2);
								if(fenxi6=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi6=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi6=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi6=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi6=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi6=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi6=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi6=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi6=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi6=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi6=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi7=BAG.substr(12,2);
								if(fenxi7=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi7=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi7=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi7=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi7=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi7=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi7=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi7=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi7=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi7=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi7=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi8=BAG.substr(14,2);
								if(fenxi8=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi8=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi8=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi8=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi8=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi8=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi8=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi8=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi8=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi8=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi8=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi9=BAG.substr(16,2);
								if(fenxi9=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi9=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi9=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi9=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi9=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi9=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi9=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi9=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi9=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi9=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi9=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi10=BAG.substr(18,2);
								if(fenxi10=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi10=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi10=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi10=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi10=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi10=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi10=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi10=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi10=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi10=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi10=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
							}
							if(lenth/2==11)
							{
								fenxi=BAG.substr(0,2);
								if(fenxi=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi2=BAG.substr(2,2);
								if(fenxi2=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi2=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi2=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi2=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi2=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi2=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi2=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi2=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi2=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi2=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi2=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi3=BAG.substr(4,2);
								if(fenxi3=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi3=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi3=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi3=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi3=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi3=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi3=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi3=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi3=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi3=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi3=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi4=BAG.substr(6,2);
								if(fenxi4=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi4=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi4=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi4=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi4=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi4=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi4=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi4=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi4=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi4=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi4=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi5=BAG.substr(8,2);
								if(fenxi5=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi5=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi5=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi5=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi5=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi5=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi5=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi5=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi5=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi5=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi5=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi6=BAG.substr(10,2);
								if(fenxi6=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi6=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi6=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi6=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi6=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi6=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi6=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi6=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi6=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi6=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi6=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi7=BAG.substr(12,2);
								if(fenxi7=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi7=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi7=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi7=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi7=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi7=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi7=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi7=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi7=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi7=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi7=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi8=BAG.substr(14,2);
								if(fenxi8=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi8=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi8=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi8=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi8=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi8=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi8=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi8=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi8=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi8=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi8=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi9=BAG.substr(16,2);
								if(fenxi9=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi9=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi9=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi9=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi9=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi9=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi9=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi9=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi9=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi9=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi9=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi10=BAG.substr(18,2);
								if(fenxi10=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi10=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi10=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi10=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi10=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi10=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi10=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi10=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi10=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi10=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi10=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
								fenxi11=BAG.substr(20,2);
								if(fenxi11=="01")
								{
									cout<<"新手铁剑"<<" "<<endl;
								}
								if(fenxi11=="02")
								{
									cout<<"新手铁甲"<<" "<<endl;
								}
								if(fenxi11=="03")
								{
									cout<<"雾切之回光"<<" "<<endl;
								}
								if(fenxi11=="04")
								{
									cout<<"精良铁甲"<<" "<<endl;
								}
								if(fenxi11=="05")
								{
									cout<<"烈火剑"<<" "<<endl;
								}
								if(fenxi11=="06")
								{
									cout<<"烈火套装"<<" "<<endl;
								}
								if(fenxi11=="07")
								{
									cout<<"终末磋叹之诗"<<" "<<endl;
								}
								if(fenxi11=="08")
								{
									cout<<"传说套装"<<" "<<endl;
								}
								if(fenxi11=="09")
								{
									cout<<"天空之脊"<<" "<<endl;
								}
								if(fenxi11=="10")
								{
									cout<<"神·最终支配之剑"<<" "<<endl;
								}
								if(fenxi11=="11")
								{
									cout<<"神·最终守护之甲"<<" "<<endl;
								}
							}
							string choosething,fenxiiiiii1,fenxiiiiii2,fenxiiiiii3,fenxiiiiii4,fenxiiiiii5,fenxiiiiii6,fenxiiiiii7,fenxiiiiii8,fenxiiiiii9,fenxiiiiii10,fenxiiiiii11;
							cout<<"请在上面选择你要装备的："<<endl;
							cin>>choosething;
							if(fenxi2=="01" || fenxi=="01" || fenxi3=="01"|| fenxi4=="01" || fenxi5=="01" ||  fenxi6=="01" || fenxi7=="01" || fenxi8=="01" || fenxi9=="01" || fenxi10=="01" || fenxi11=="01")
							{
								fenxiiiiii1="1";
							}
							if(fenxi2=="02" || fenxi=="02" || fenxi3=="02"|| fenxi4=="02" || fenxi5=="02" ||  fenxi6=="02" || fenxi7=="02" || fenxi8=="02" || fenxi9=="02" || fenxi10=="02" || fenxi11=="02")
							{
								fenxiiiiii2="1";
							}
							if(fenxi2=="03" || fenxi=="03" || fenxi3=="03"|| fenxi4=="03" || fenxi5=="03" ||  fenxi6=="03" || fenxi7=="03" || fenxi8=="03" || fenxi9=="03" || fenxi10=="02" || fenxi11=="03")
							{
								fenxiiiiii3="1";
							}
							if(fenxi2=="04" || fenxi=="04" || fenxi3=="04"|| fenxi4=="04" || fenxi5=="04" ||  fenxi6=="04" || fenxi7=="04" || fenxi8=="04" || fenxi9=="04" || fenxi10=="04" || fenxi11=="04")
							{
								fenxiiiiii4="1";
							}
							if(fenxi2=="05" || fenxi=="05" || fenxi3=="05"|| fenxi4=="05" || fenxi5=="05" ||  fenxi6=="05" || fenxi7=="05" || fenxi8=="05" || fenxi9=="05" || fenxi10=="05" || fenxi11=="05")
							{
								fenxiiiiii5="1";
							}
							if(fenxi2=="06" || fenxi=="06" || fenxi3=="06"|| fenxi4=="06" || fenxi5=="06" ||  fenxi6=="06" || fenxi7=="06" || fenxi8=="06" || fenxi9=="06" || fenxi10=="06" || fenxi11=="06")
							{
								fenxiiiiii6="1";
							}
							if(fenxi2=="07" || fenxi=="07" || fenxi3=="07"|| fenxi4=="07" || fenxi5=="07" ||  fenxi6=="07" || fenxi7=="07" || fenxi8=="07" || fenxi9=="07" || fenxi10=="07" || fenxi11=="07")
							{
								fenxiiiiii7="1";
							}
							if(fenxi2=="08" || fenxi=="08" || fenxi3=="08"|| fenxi4=="08" || fenxi5=="08" ||  fenxi6=="08" || fenxi7=="08" || fenxi8=="08" || fenxi9=="08" || fenxi10=="08" || fenxi11=="08")
							{
								fenxiiiiii8="1";
							}
							if(fenxi2=="09" || fenxi=="09" || fenxi3=="09"|| fenxi4=="09" || fenxi5=="09" ||  fenxi6=="09" || fenxi7=="09" || fenxi8=="09" || fenxi9=="09" || fenxi10=="09" || fenxi11=="09")
							{
								fenxiiiiii9="1";
							}
							if(fenxi2=="10" || fenxi=="10" || fenxi3=="10"|| fenxi4=="10" || fenxi5=="10" ||  fenxi6=="10" || fenxi7=="10" || fenxi8=="10" || fenxi9=="10" || fenxi10=="10" || fenxi11=="10")
							{
								fenxiiiiii10="1";
							}
							if(fenxi2=="11" || fenxi=="11" || fenxi3=="11"|| fenxi4=="11" || fenxi5=="11" ||  fenxi6=="11" || fenxi7=="11" || fenxi8=="11" || fenxi9=="11" || fenxi10=="11" || fenxi11=="11")
							{
								fenxiiiiii11="1";
							}
							if(choosething=="新手铁剑" && fenxiiiiii1=="1")
							{
								std::ofstream ofile("./Inf/user/bag/now.txt");
								ofile <<"01"<<endl;
							}
							if(choosething=="新手铁甲" && fenxiiiiii2=="1")
							{
								std::ofstream ofile("./Inf/user/bag/nowzb.txt");
								ofile <<"02"<<endl;
							}
							if(choosething=="雾切之回光" && fenxiiiiii3=="1")
							{
								std::ofstream ofile("./Inf/user/bag/now.txt");
								ofile <<"03"<<endl;
							}
							if(choosething=="精良铁甲" && fenxiiiiii4=="1")
							{
								std::ofstream ofile("./Inf/user/bag/nowzb.txt");
								ofile <<"04"<<endl;
							}
							if(choosething=="烈火剑" && fenxiiiiii5=="1")
							{
								std::ofstream ofile("./Inf/user/bag/now.txt");
								ofile <<"05"<<endl;
							}
							if(choosething=="烈火套装" && fenxiiiiii6=="1")
							{
								std::ofstream ofile("./Inf/user/bag/nowzb.txt");
								ofile <<"06"<<endl;
							}
							if(choosething=="终末磋叹之诗" && fenxiiiiii7=="1")
							{
								std::ofstream ofile("./Inf/user/bag/now.txt");
								ofile <<"07"<<endl;
							}
							if(choosething=="传说套装" && fenxiiiiii8=="1")
							{
								std::ofstream ofile("./Inf/user/bag/nowzb.txt");
								ofile <<"08"<<endl;
							}
							if(choosething=="天空之脊" && fenxiiiiii9=="1")
							{
								std::ofstream ofile("./Inf/user/bag/now.txt");
								ofile <<"09"<<endl;
							}
							if(choosething=="神·最终支配之剑" && fenxiiiiii10=="1")
							{
								std::ofstream ofile("./Inf/user/bag/now.txt");
								ofile <<"10"<<endl;
							}
							if(choosething=="神·最终守护之甲" && fenxiiiiii11=="1")
							{
								std::ofstream ofile("./Inf/user/bag/nowzb.txt");
								ofile <<"11"<<endl;
							}
							cout<<"已装备："<<choosething<<endl;
						}
						if(choosezhuangbei==2)
						{
							if(rnowwp=="新手铁剑")
							{
								wpatt=1;
								wpblo=500;
								wpbt=10;
								wpdef=10;
							}
							if(rnowwp=="雾切之回光")
							{
								wpatt=0;
								wpbt=1288;
								wpdef=-10;
							}
							if(rnowwp=="烈火剑")
							{
								wpatt=50;
								wpblo=1200;
								wpbt=88;
								wpdef=10;
							}
							if(rnowwp=="终末磋叹之诗")
							{
								wpatt=88;
								wpbt=180;
								wpblo=888;
								wpdef=20;
							}
							if(rnowwp=="天空之脊")
							{
								wpatt=188;
								wpbt+=122;
								wpblo=2000;
								wpdef=5;
							}
							if(rnowwp=="神·最终支配之剑")
							{
								wpblo=28888;
								wpbt=30088;
								wpatt=228288;
								wpdef=208;
							}
							if(rnowzb=="新手铁甲")
							{
								zbblo=999999;
								zbdef=999999;
								zbatt=9999;
								zbbt=9999;
							}
							if(rnowzb=="精良铁甲")
							{
								zbblo=500;
								zbdef=40;
								zbatt=0;
								zbbt=0;
							}
							if(rnowzb=="烈火套装")
							{
								zbblo=400;
								zbdef=65;
								zbatt=0;
								zbbt=0;
							}
							if(rnowzb=="传说套装")
							{
							    zbblo=1000;
								zbdef=55;
								zbatt=0;
								zbbt=0;
							}
							if(rnowzb=="神·最终守护之甲")
							{
								zbatt=8888;
								zbbt=5888;
								zbblo=2088;
								zbdef=8088;
							}
							int backiii;
							ratt=wpatt+zbatt+10;
							rbt=wpbt+zbbt+50;
							rblood=wpblo+zbblo+500;
							rdef=wpdef+zbdef+10;
							cout<<"生命："<<rblood<<endl;
							cout<<"攻击："<<ratt<<endl;
							cout<<"暴击伤害："<<rbt<<endl;
							cout<<"暴击率：50%"<<endl;
							cout<<"免疫率："<<rdef<<endl;
							cout<<"1.返回——————》"<<endl;
							cin>>backiii;
							if(backiii==1)
							{
								//返回
							}
						}
						if(choosezhuangbei==3)
						{
							//返回
						}
						//角色信息
					}
					if(chooseG==4)
					{
						int backinf;
						cout<<"名称："<<gameNAME<<endl;
						cout<<"等级："<<levelLO<<endl;
						cout<<"经验: "<<exp<<endl;
						cout<<"摩尼："<<moni<<endl;
						cout<<"1.返回——————》"<<endl;
						cin>>backinf;
						if(backinf==1)
	                    {
							//返回
						}
						//综合信息
					}
					if(chooseG==5)
					{
						//账户系统
					}
					if(chooseG==6)
					{
						string pathHD = "./Inf/user/hd.txt";
						ifstream in_fileHD(pathHD, ios::in);
						string HD;
						getline(in_fileHD,HD);//读活动信息
						int getnoobthing;
						cout<<"新手礼包二件套（新手铁剑、新手铁甲）：（1领取 2返回）"<<endl;
						cin>>getnoobthing;
						if(getnoobthing==1 && HD=="0")
						{
							cout<<"您获得了：新手铁剑、新手铁甲。"<<endl;
							string pathWP= "./Inf/user/bag/bagwp.txt"; 
							ofstream out_fileWP(pathWP, ios::out | ios::app); 
							out_fileWP<<"01";//写入新手铁剑物品信息、
							
							Sleep(1000);
							
							string pathWP2= "./Inf/user/bag/bagwp.txt"; 
							ofstream out_fileWP2(pathWP2, ios::out | ios::app); 
							out_fileWP2<<"02";//写入新手铁甲物品信息
							
							std::ofstream ofile("./Inf/user/hd.txt");
							ofile << "1"; //写入已经使用活动
						}
						if(getnoobthing==1 && HD=="1")
						{
							cout<<"您已经领取过了！"<<endl;
						}
						//活动系统
					}
					if(chooseG==7)
					{
						cout<<"2022/08/18:"<<endl;
						cout<<"开放主线1-1."<<endl;
						cout<<"2022/08/17:"<<endl;
						cout<<"开发背包以及更换装备和数据面板功能."<<endl;
						cout<<"2022/08/16:"<<endl;
						cout<<"开发登录注册系统."<<endl;
						cout<<"温馨提示:在您开始任何游戏前，请先打开数据面板（3.角色---》2.数据面板),否则会出现伤害不正常的问题。。"<<endl;
						cout<<"温馨提示:请记得领取新手礼包（6.活动---》1.领取---》返回),新手礼包极其重要！它可以帮助您度过前期！"<<endl;
					}
				}

			}	
		}
		if(gamerinf!=BACKUPgamerinf )
		{
			string pathUID = "./log/uid log.txt";
			ifstream in_fileUID(pathUID, ios::in);
			string UIDlo;
			getline(in_fileUID, UIDlo); //读取uid数据
			
			cout<<"检测到客户端数据异常 错误代码：1X00"<<endl;
			Sleep(2000);
			cout<<"数据变化，程序即将关闭。"<<endl;
			string pathBAN= "./Inf/user/ban.txt"; 
			ofstream out_fileBAN(pathBAN, ios::out | ios::app); 
			out_fileBAN<<"1";//写入封禁信息
			
			string pathBANT= "./Inf/user/time.txt"; 
			ofstream out_fileBANT(pathBANT, ios::out | ios::app); 
			out_fileBANT<<DAY;//写入时间
			
			return 0;
		}
	}
	if(BAN=="01" && BANday!=DAY )
	{
		string pathUIDA = "./log/uid log.txt";
		ifstream in_fileUIDA(pathUIDA, ios::in);
		string UIDloL;
		getline(in_fileUIDA, UIDloL); //读取uid数据
		
		cout<<"UID："<<UIDloL<<"账号："<<enrollinf<<"您已被封禁账号，解封时间："<<YEAR<<"年"<<MON<<"月 "<<DAY<<"日";
		cout<<"若您对处罚有异议，请联系客服：邮箱：cpddabc@126.com 或 qq:2833379812"<<endl;
	}
    if(BAN=="01" && BANday==DAY)
	{
		cout<<"您的账号已解封，希望您在以后的游戏中，绝对绿色，公平公正！"<<endl;
		cout<<"                                         -----Maker:lemonp"<<endl;
		string pathBANc= "./Inf/user/ban.txt"; 
		ofstream out_fileBANc(pathBANc, ios::out | ios::app); 
		out_fileBANc<<"0";//写入解封信息
		cout<<"再次打开即可进入界面。。"<<endl;
		return 0;
	}
	if(BAN=="0101" && YEAR!=TWOYEAR )
	{
		string pathUIDAV = "./log/uid log.txt";
		ifstream in_fileUIDAV(pathUIDAV, ios::in);
		string UIDloLLL;
		getline(in_fileUIDAV, UIDloLLL); //读取uid数据
		
		
		cout<<"UID："<<UIDloLLL<<"账号："<<enrollinf<<"您已被封禁账号，解封时间："<<TWOYEAR<<"年"<<MON<<"月"<<DAY<<"日";
		cout<<"若您对处罚有异议，请联系客服：邮箱：cpddabc@126.com 或 qq:2833379812"<<endl;
	}
	if(BAN=="0101" && YEAR==TWOYEAR)
	{
		cout<<"您的账号已解封，希望您在以后的游戏中，绝对绿色，公平公正！"<<endl;
		cout<<"                                         -----Maker:lemonp"<<endl;
		string pathBANc= "./Inf/user/ban.txt"; 
		ofstream out_fileBANc(pathBANc, ios::out | ios::app); 
		out_fileBANc<<"0";//写入解封信息
		cout<<"再次打开即可进入界面。。"<<endl;
		return 0;
	}
	if(BAN=="01010")
	{
		cout<<"因你多次违反游戏规则，现已将您的账户永久冻结。"<<endl;
	}
	return 0;
}
